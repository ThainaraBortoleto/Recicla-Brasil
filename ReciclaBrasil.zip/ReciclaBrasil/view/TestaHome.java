public class TestaHome {
	public static void main(String[] args) {
		new Home();
		
	}
}
